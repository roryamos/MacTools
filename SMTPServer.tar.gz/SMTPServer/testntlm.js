/* eslint no-console: 0 */

'use strict';


const SMTPConnection = require('smtp-connection');
const authconn = new SMTPConnection({
	//host: 'mail.iv66.net',
	host: '10.71.40.26',
	port: 25,
	ignoreTLS: true,
	name: 'gogs',
	logger: true,
	debug: true,
	authMethod: 'ntlm'
});
console.log(authconn);
authconn.connect(function(){
	authconn.login({user:'twrory', pass:'123456', domain:'iv66.net'}, function(){
		authconn.close();
	});
});
