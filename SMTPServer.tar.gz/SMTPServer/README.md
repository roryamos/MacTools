# role #
gogs <-> Fake SMTP server <-> exchange server

# how to #
npm install -g pm2  
git clone this project  
change directory npm install  
pm2 start server.js  


